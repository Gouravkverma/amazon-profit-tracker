package com.amazon.pnl.amazon_pnl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmazonPnlApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmazonPnlApplication.class, args);
	}

}
