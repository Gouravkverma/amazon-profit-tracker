package com.amazon.pnl.amazon_pnl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonPnlApplicationTests {

	@Test
	void contextLoads() {
	}

}
